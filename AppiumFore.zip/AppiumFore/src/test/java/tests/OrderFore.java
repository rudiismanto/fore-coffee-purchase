package tests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.offset.PointOption;

public class OrderFore {
	
	
	AppiumDriver<MobileElement> driver;

	@BeforeTest
	public void setup () throws Exception  {

		DesiredCapabilities dc = new DesiredCapabilities();
//		dc.setCapability(MobileCapabilityType.PLATFORM_NAME, "ANDROID");
//		dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "10");
//		dc.setCapability(MobileCapabilityType.UDID, "054783705J006494");
		dc.setCapability("platformName", "android");
		dc.setCapability("appPackage", "coffee.fore2.fore");
		dc.setCapability("appActivity", "coffee.fore2.fore.MainActivity");
		dc.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 80);
		URL url = new URL("http://127.0.0.1:4723/wd/hub");
		
		driver = new AppiumDriver<MobileElement>(url,dc);
		driver.resetApp();
	}
	
	@Test
	public void test1() throws InterruptedException {
		System.out.println("Test Begin");
		Thread.sleep(3000);
		TouchAction ta = new TouchAction(driver);
		ta.press(PointOption.point(115, 1400))
		.moveTo(PointOption.point(650, 1400)).release().perform();
		driver.findElementById("coffee.fore2.fore:id/wlk_close_button").click();
		Thread.sleep(2000);
		driver.findElementById("coffee.fore2.fore:id/header_bar_left_layout").click();
		Thread.sleep(1000);
		driver.findElementById("coffee.fore2.fore:id/button_text_button").click();
		Thread.sleep(1000);
		driver.findElementById("com.android.permissioncontroller:id/permission_allow_foreground_only_button").click();
		Thread.sleep(4000);
		driver.navigate().back();
		Thread.sleep(1000);
		driver.findElementById("coffee.fore2.fore:id/home_text_order_label").click();
		
		/*kehalaman menu dan memasukan menu manuka americano ke keranjang*/
		Thread.sleep(6000);
		driver.findElementByXPath("//android.widget.TextView[@text='Manuka Series']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.TextView[@text='Manuka Americano']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.TextView[@text='ICE CUBE']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.TextView[@text='Less Ice']").click();
		Thread.sleep(1000);
		MobileElement syrup = (MobileElement) driver.findElement(
				MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector()).scrollIntoView("
				+ "new UiSelector().text(\"SYRUP\"));"));
		syrup.click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.TextView[@text='Aren']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.Button[@text='MASUK KERANJANG � RP 32.000']").click();
		Thread.sleep(3000);
		
		/*kembali kehalaman menu dan memasukan menu espresso ke keranjang*/
		driver.findElementByXPath("//android.widget.TextView[@text='Indonesia Flavor']").click();
		Thread.sleep(1000);
		
		ta.press(PointOption.point(170, 1100))
		.moveTo(PointOption.point(170, 200)).release().perform();
		
		driver.findElementByXPath("//android.widget.TextView[@text='Espresso']").click();
		Thread.sleep(1000);

		MobileElement element = (MobileElement) driver.findElementById("coffee.fore2.fore:id/product_detail_product_price");
		String harga = element.getText();
		System.out.println(harga);
		
		if(harga.equals("Rp 17.000"))
		{
			System.out.println("Harga Cocok");
		}
		else
		{
			System.out.println("Harga Tidak Cocok");
			driver.executeScript("client:client.report('msg : test fail',false)");
		}
		
	}
	
	/////////////////////////////////////////////////////////////////////////////
	
	@Test
	public void test2() throws InterruptedException {
		MobileElement pesan = (MobileElement) driver.findElement(
				MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector()).scrollIntoView("
				+ "new UiSelector().text(\"Pesan Sekarang\"));"));
		driver.findElementByXPath("//android.widget.Button[@text='MASUK KERANJANG � RP 17.000']").click();
		Thread.sleep(1000);
		
		MobileElement element2 = (MobileElement) driver.findElementById("coffee.fore2.fore:id/catalog_header_cart_count");
		String cartcount = element2.getText();
		String a = "2";

		if(cartcount.equals(a))
		{
			System.out.println("Jumlah Pesanan Sesuai");
		}
		else
		{
			System.out.println("Jumlah Pesanan Tidak Sesuai");
			driver.executeScript("client:client.report('msg : test fail',false)");
		}
	}
	
	/////////////////////////////////////////////////////////////////////////////
	
	@Test
	public void test3() throws InterruptedException {
		driver.findElementById("coffee.fore2.fore:id/catalog_header_cart_icon").click();
		Thread.sleep(1000);
		driver.findElementById("coffee.fore2.fore:id/button_add_more").click();
		Thread.sleep(1000);
				
		/*kembali kehalaman menu dan memasukan menu Stainless straw ke keranjang*/
		TouchAction ta = new TouchAction(driver);
		ta.press(PointOption.point(70, 1400))
		.moveTo(PointOption.point(70, 300)).release().perform();
		driver.findElementByXPath("//android.widget.TextView[@text='Merchandise']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.TextView[@text='Stainless Straw']").click();
		Thread.sleep(1000);
		driver.findElementByXPath("//android.widget.Button[@text='MASUK KERANJANG � RP 22.000']").click();
		Thread.sleep(3000);
		driver.findElementById("coffee.fore2.fore:id/cart_summary_cardview").click();
		Thread.sleep(1000);
		driver.findElementById("coffee.fore2.fore:id/input_text_input").click();
		driver.getKeyboard().sendKeys("8000");
		driver.findElementById("coffee.fore2.fore:id/input_text_icon").click();
		Thread.sleep(1000);
		
		if(driver.findElementById("coffee.fore2.fore:id/input_text_icon").isDisplayed())
		{
			System.out.println("No Hp yang anda masukan tidak valid. Error tampil");
		}
		else
		{
			System.out.println("No Hp yang anda masukan valid. Masuk ke halaman OTP");
			driver.executeScript("client:client.report('msg : test fail',false)");
		}
		
	}	
}
